# bundle fixture

## Summary
- Session ID: `ses_20260622_xi2jhm`
- Status: Open
- Created: 2026-06-22 15:14:33.147554514 +00:00:00
- Repository: /tmp/tmp.fdymqwNHRO
- Initial HEAD: `07cee350ebf39e69f39ef3e26ef371f3007d2c99`
- Events: 5

## Commands
- `2026-06-22 15:14:33.157166814 +00:00:00` `cmd_u5yw3n6a` exit 0 (0 ms)

## Notes
- None recorded

## Git Snapshots
- HEAD `07cee350ebf39e69f39ef3e26ef371f3007d2c99` on `main` (dirty=true)
- HEAD `07cee350ebf39e69f39ef3e26ef371f3007d2c99` on `main` (dirty=true)

## Timeline
- `2026-06-22 15:14:33.151411441 +00:00:00` seq 1 — session.started
- `2026-06-22 15:14:33.154838207 +00:00:00` seq 2 — git.snapshot
- `2026-06-22 15:14:33.156703922 +00:00:00` seq 3 — command.started
- `2026-06-22 15:14:33.157166814 +00:00:00` seq 4 — command.finished
- `2026-06-22 15:14:33.161970524 +00:00:00` seq 5 — git.snapshot

## Verification
- Event chain: verified